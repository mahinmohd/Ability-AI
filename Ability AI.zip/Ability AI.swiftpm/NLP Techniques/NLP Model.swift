import SwiftUI
import NaturalLanguage

struct NLPModel: View {
    
    // Input Text Variables
    @State var TokenText = ""
    @State var LemmaText = ""
    @State var POStext = ""
    
    // NL Frameworks/Libraries
    let tokenizer = NLTokenizer(unit: .word)
    let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
    let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation]
    
    // Message to the User State
    @State private var SeenMessage = false
    @State var showMessage = false
    
    @State private var tokens: [String] = []
    @State private var selectedToken: String?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea(edges: .all)
            VStack(spacing: 20) {
                
                Text("NLP Steps")
                    .font(.largeTitle.lowercaseSmallCaps().bold())
                    .underline(color: Color.indigo)
                
                HStack(spacing: 10) {
                    // Source of Text: ChatGPT
                    Button(action: {
                        TokenText = "The quick brown fox jumps over the lazy dog."
                        LemmaText = "The children went to the park and played on the swings."
                        POStext = "I am reading a book on natural language processing."
                    }) {
                        Text("Try out with Sample Text")
                            .foregroundColor(.white)
                            .font(.title3.smallCaps())
                            .padding()
                            .background(Color.yellow.opacity(0.7))
                            .cornerRadius(25)
                            .shadow(color: .black, radius: 20, x: 0, y: 10)
                            .padding(.top, 50)
                    }
                    
                    // Button to Clear all text fields
                    Button(action: {
                        withAnimation(.easeOut(duration: 0.4)) {
                            self.TokenText = ""
                            self.LemmaText = ""
                            self.POStext = ""
                            self.tokenize()
                            self.lemmatize()
                            self.tagPartsOfSpeech()
                        }
                    }) {
                        Text("Clear")
                            .foregroundColor(.white)
                            .font(.title3.smallCaps())
                            .padding()
                            .background(Color.yellow.opacity(0.3))
                            .cornerRadius(25)
                            .shadow(color: .black, radius: 20, x: 0, y: 10)
                            .padding(.top, 50)
                    }
                }
                
                VStack(spacing: 15) {
                    
                    HStack(spacing: 20) {
                        
                        // Tokenization
                        // Button to Clear the Input text
                        Button(action: {
                            withAnimation(.easeOut(duration: 0.4)) {
                                self.TokenText = ""
                                self.tokenize()
                            }
                        }) {
                            Text("Clear")
                                .frame(width: 110, height: 50, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.cyan.opacity(0.2))
                                .cornerRadius(15)
                        }
                        
                        TextField("Tokenize Anything...", text: $TokenText)
                            .padding()
                            .background(Color.cyan.opacity(0.2))
                            .cornerRadius(15)
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.cyan, lineWidth: 2)
                            )
                            .shadow(color: .cyan.opacity(1), radius: 10, x: 0, y: 10)
                            .onSubmit {
                                withAnimation(.easeIn(duration: 0.5)) {
                                    self.tokenize()
                                }
                            }
                        
                        Button(action: {
                            withAnimation(.easeIn(duration: 0.5)) {
                                self.tokenize()
                            }
                        }) {
                            Text("Tokenize")
                                .frame(width: 110, height: 50, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.cyan.opacity(0.8))
                                .cornerRadius(15)
                        }
                    }
                    
                    HStack(spacing: 20) {
                        
                        // Lemmatization
                        // Button to Clear the Input text
                        Button(action: {
                            withAnimation(.easeOut(duration: 0.4)) {
                                self.LemmaText = ""
                                self.lemmatize()
                            }
                        }) {
                            Text("Clear")
                                .frame(width: 110, height: 50, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.green.opacity(0.2))
                                .cornerRadius(15)
                        }
                        
                        TextField("Lemmatize the words...", text: $LemmaText)
                            .padding()
                            .background(Color.green.opacity(0.2))
                            .cornerRadius(15)
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.green, lineWidth: 2)
                            )
                            .shadow(color: .green.opacity(1), radius: 10, x: 0, y: 10)
                            .onSubmit {
                                withAnimation(.easeIn(duration: 0.5)) {
                                    self.lemmatize()
                                }
                            }
                        
                        Button(action: {
                            withAnimation(.easeIn(duration: 0.5)) {
                                self.lemmatize()
                            }
                        }) {
                            Text("Lemmatize")
                                .frame(width: 110, height: 50, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.green.opacity(0.8))
                                .cornerRadius(15)
                        }
                    }
                    
                    HStack(spacing: 20) {
                        
                        // Parts Of Speech Tagging
                        // Button to Clear the Input text
                        Button(action: {
                            withAnimation(.easeOut(duration: 0.4)) {
                                self.POStext = ""
                                self.tagPartsOfSpeech()
                            }
                        }) {
                            Text("Clear")
                                .frame(width: 110, height: 50, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.blue.opacity(0.2))
                                .cornerRadius(15)
                        }
                        
                        TextField("Tag Parts of Speech...", text: $POStext)
                            .padding()
                            .frame(height: 70, alignment: .center)
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(15)
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.blue, lineWidth: 2)
                            )
                            .shadow(color: .blue.opacity(1), radius: 10, x: 0, y: 10)
                            .onSubmit { 
                                withAnimation(.easeIn(duration: 0.5)) {
                                    self.tagPartsOfSpeech()
                                }
                            }
                        // For Part Of Speech Tagging (POS)
                        Button(action: {
                            withAnimation(.easeIn(duration: 0.5)) {
                                self.tagPartsOfSpeech()
                            }
                        }) {
                            Text("Tag Parts of Speech")
                                .frame(width: 110, height: 70, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.blue.opacity(0.8))
                                .cornerRadius(15)
                        }
                    }
                    Button(action: {
                        withAnimation(
                            showMessage ? .easeOut(duration: 0.5) : .easeIn(duration: 0.5)
                        ) {
                            self.showMessage.toggle()
                        }
                    }) {
                        Text(showMessage ? "Hide Info" : "Show Info")
                            .frame(width: 110, height: 70, alignment: .center)
                            .font(.title3.smallCaps())
                            .foregroundColor(.white)
                            .background(Color.indigo.opacity(0.8))
                            .cornerRadius(15)
                    }
                }
                .padding(.all, 30)
                
                // Message to the User 
                if showMessage {
                    VStack {
                        ScrollView {
                            
                            // What's Tokenization?
                            Message(centerText: "What is Tokenization? \n", paraText: "Tokenization is the process of breaking large blocks of text into smaller blocks called Tokens. These tokens can be words, phrases, or even single characters separated by special characters such as spaces, apostrophes, or other characters.\n\nSymbolization is often used in Natural Language Processing (NLP) to prepare data for analysis. Computers can more easily understand and process information by breaking down text into smaller chunks. It can also be helpful in tasks such as Text classification, Sentiment analysis, and Machine translation.", color: Color.cyan.opacity(0.4))//, height: 450)
                            
                            // What's Lemmatization?
                            Message(centerText: "What is Lemmatization? \n", paraText: "Lemmatization is a natural language processing process that involves reducing words to their simplest form, or \"lemma\". This is done by removing any inflections or suffixes added to the word to get its original meaning. For example, the word \"running\" can be reduced to the root \"run\" by lemmatization. Similarly, \"timing\" can be simplified to \"time\", \"caring\" can be simplified to \"care\", and so on. \n\nLemmatization is important in Natural Language Processing as it can help improve the accuracy of text analysis. By reducing words to their simplest form, computers can more easily recognize and group words with the same root meaning. \n\nThis is particularly useful for tasks such as Data collection, Text classification, and Sentiment analysis.", color: Color.green.opacity(0.4))//, height: 600)
                            
                            // What's POS Tagging?
                            Message(centerText: "What is Part-Of-Speech Tagging? \n", paraText: "Part Of Speech (POS) Tagging is a linguistic technique that involves identifying parts of a sentence such as nouns, verbs, adjectives, adverbs, pronouns, prepositions, conjunctions, and exclamations. Speech tagging is often used to help computers understand the meaning and structure of sentences. Computers can more easily interpret sentences from whole words with the corresponding part of speech and analyze their meaning. \n\nTake for example the sentence: \"The cat is sitting on the mat.\" In this sentence, \"the\" is a Determiner, \"cat\" is a Noun, \"sat\" is a Verb, \"on\" is a Preposition. , and such. By tagging each word with the relevant part of speech, the computer can better understand the sentence and its meaning. \n\nSpeech segment tagging is particularly useful for tasks such as Text analysis, Text classification, and Machine translation.", color: Color.blue.opacity(0.4))//, height: 600)
                        }
                    }
                }
                
                List(tokens, id: \.self) { token in
                    Text(token)
                        .padding(.all)
                        .frame(height: 50)
                        .background(Color.mint.opacity(0.5))
                        .cornerRadius(20)
                        .foregroundColor(token == self.selectedToken ? .black : .primary)
                        .onTapGesture {
                            self.selectedToken = token
                        }
                }
            }
            .padding(.top)
        }
    }
    
    // Tokenization
    func tokenize() {
        tokenizer.string = TokenText
        var newTokens: [String] = []
        tokenizer.enumerateTokens(in: TokenText.startIndex..<TokenText.endIndex) { tokenRange, _ in
            newTokens.append(String(TokenText[tokenRange]))
            return true
        }
        self.tokens = newTokens
    }
    
    // Lemmatization
    func lemmatize() {
        tagger.string = LemmaText
        var newTokens: [String] = []
        tagger.enumerateTags(in: LemmaText.startIndex..<LemmaText.endIndex, unit: .word, scheme: .lemma) { tag, tokenRange in
            if let tag = tag {
                let lemma = String(tag.rawValue)
                newTokens.append(lemma)
            } else {
                newTokens.append(String(LemmaText[tokenRange]))
            }
            return true
        }
        self.tokens = newTokens
    }
    
    // Parts-Of-Speech Tagging
    func tagPartsOfSpeech() {
        tagger.string = POStext
        var newTokens: [String] = []
        tagger.enumerateTags(in: POStext.startIndex..<POStext.endIndex, unit: .word, scheme: .lexicalClass, options: options) { tag, tokenRange in
            if let tag = tag {
                let pos = String(tag.rawValue)
                newTokens.append("\(POStext[tokenRange]): \(pos)")
            } else {
                newTokens.append(String(POStext[tokenRange]))
            }
            return true
        }
        self.tokens = newTokens
    }
    
}

struct NLPModel_Previews: PreviewProvider {
    static var previews: some View {
        NLPModel()
    }
}
