import SwiftUI

struct Stemming: View {
    var body: some View {
        Text("Stemming")
    }
}

struct Stemming_Previews: PreviewProvider {
    static var previews: some View {
        Stemming()
    }
}

