import SwiftUI

struct Buttons: View {
    
    let color: Color
    let text: String
    let Destination: AnyView
    
    var body: some View {
        NavigationLink(
            destination: Destination,
            label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.clear)
                    Text(text)
                        .font(.title2)
                        .bold()
                        .foregroundColor(.white)
                }
                .frame(width: 300, height: 70, alignment: .center)
                .background(color)
                .cornerRadius(20)
                .contentShape(RoundedRectangle(cornerRadius: 20))
            })
    }
}
