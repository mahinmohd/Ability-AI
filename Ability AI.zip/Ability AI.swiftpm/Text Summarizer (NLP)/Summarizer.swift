import SwiftUI
import NaturalLanguage

struct TextSummarizer: View {
    
    @State private var inputText: String = ""
    @State private var summaryText: String = ""
    @State var buttonTapped = false
    
    var inWordCout: Int {
        let words = inputText.trimmingCharacters(in: .whitespacesAndNewlines).components(separatedBy: .whitespacesAndNewlines)
        return words.count == 1 && words.first == "" ? 0 : words.count
    }
    
    var fiWordCout: Int {
        let words = summaryText.trimmingCharacters(in: .whitespacesAndNewlines).components(separatedBy: .whitespacesAndNewlines)
        return words.count == 1 && words.first == "" ? 0 : words.count
    }
    
    var body: some View {
        ZStack {
            Color.blue.opacity(0.21).ignoresSafeArea(.all)
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    Text("Text Summarizer")
                        .font(.largeTitle.smallCaps())
                        .bold()
                        .underline(true, color: .cyan)
                        .frame(maxWidth: .infinity, alignment: .center)
                        .shadow(color: .black, radius: 10, x: 0, y: 10)
                    
                    HStack {
                        
                        // Sample Text Button
                        // Source of Text: Wikipedia
                        Button(action: {
                            inputText = """
Apple Inc. is an American multinational technology company headquartered in Cupertino, California. Apple is the world's largest technology company by revenue, with US$394.3 billion in 2022 revenue. As of March 2023, Apple is the world's biggest company by market capitalization. As of June 2022, Apple is the fourth-largest personal computer vendor by unit sales and second-largest mobile phone manufacturer. It is one of the Big Five American information technology companies, alongside Alphabet Inc. (parent company of Google), Amazon, Meta Platforms (formerly for Facebook Inc), and Microsoft. Apple was founded as Apple Computer Company on April 1, 1976, by Steve Wozniak, Steve Jobs and Ronald Wayne to develop and sell Wozniak's Apple I personal computer. It was incorporated by Jobs and Wozniak as Apple Computer, Inc. in 1977. The company's second computer, the Apple II, became a best seller and one of the first mass-produced microcomputers. Apple went public in 1980 to instant financial success. The company developed computers featuring innovative graphical user interfaces, including the 1984 original Macintosh, announced that year in a critically acclaimed advertisement. By 1985, the high cost of its products, and power struggles between executives, caused problems. Wozniak stepped back from Apple amicably and pursued other ventures, while Jobs resigned bitterly and founded NeXT, taking some Apple employees with him.
"""
                        }) {
                            Text("Add Sample Text")
                                .font(.title3.bold())
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.green.opacity(0.5))
                                .cornerRadius(10)
                                .shadow(color: .black, radius: 20, x: 0, y: 10)
                                .frame(maxWidth: .infinity, alignment: .center)
                        }
                    }
                    TextEditor(text: $inputText)
                        .font(.title2.smallCaps())
                        .frame(height: 150)
                        .padding(10)
                        .background(Color.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.blue, lineWidth: 5)
                        )
                        .shadow(color: .black, radius: 10, x: 0, y: 10)
                        .padding(.horizontal)
                    
                    
                    HStack {
                        
                        // Summarizing Button
                        Button(action: {
                            withAnimation(.easeIn(duration: 0.5)) {
                                summarizeText()  
                            }
                        }) {
                            Text("Summarize")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.red.opacity(0.5))
                                .cornerRadius(10)
                                .shadow(color: .black, radius: 20, x: 0, y: 10)
                        }
                        .padding(.all)
                        
                        Spacer()
            
                        // Word Counter
                        Text("Word(s) Count: \(inWordCout)")
                            .font(.title3.smallCaps())
                            .frame(width: 300, height: 50)
                            .background(Color.blue.opacity(0.5))
                            .shadow(color: Color.black, radius: 10, x: 0, y: 10)
                            .cornerRadius(30)
                        Spacer()
                        
                        // Clear Button
                        Button(action: {
                            withAnimation(.easeOut(duration: 0.5)) {
                                self.inputText = ""
                                summarizeText()  
                            }
                        }) {
                            Text("Clear")
                                .foregroundColor(.white)
                                .padding()
                                .background(Color.orange.opacity(0.5))
                                .cornerRadius(10)
                                .shadow(color: .black, radius: 20, x: 0, y: 10)
                        }
                        .padding(.all)
                    }
                    .padding(.horizontal)
                    
                    Rectangle()
                        .frame(width: .infinity, height: 10)
                        .background(Color.black)
                        .foregroundColor(Color.red.opacity(0.9))
                        .cornerRadius(40)
                    
                    Text("Summary")
                        .font(.title2.smallCaps())
                        .underline(true, color: .cyan)
                        .shadow(color: .black, radius: 10, x: 0, y: 10)
                        .padding(.horizontal)
                        .frame(maxWidth: .infinity, alignment: .center)
                    
                    Text(summaryText)
                        .font(.title3.lowercaseSmallCaps())
                        .padding(10)
                        .background(Color.black)
                        .cornerRadius(10)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.blue, lineWidth: 5)
                        )
                        .shadow(color: .black, radius: 10, x: 0, y: 10)
                        .padding(.horizontal)
                    
                    Text("Word(s) Count: \(fiWordCout)")
                        .font(.title3.smallCaps())
                        .frame(width: 300, height: 50)
                        .background(Color.blue.opacity(0.5))
                        .shadow(color: Color.black, radius: 10, x: 0, y: 10)
                        .cornerRadius(30)
                        .padding(.top)
                }
                .padding()
            }
        }
    }
    
    func summarizeText() {
        let text = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        let inputString = text.replacingOccurrences(of: "\n", with: " ")
        
        let tagger = NLTagger(tagSchemes: [.tokenType, .language, .lexicalClass, .nameType])
        tagger.string = inputString
        
        let options: NLTagger.Options = [.omitPunctuation, .omitWhitespace]
        let range = inputString.startIndex..<inputString.endIndex
        var keywords: [String] = []
        
        tagger.enumerateTags(in: range, unit: .word, scheme: .lexicalClass, options: options) { tag, tokenRange in
            if let tag = tag {
                let tagValue = tag.rawValue.lowercased()
                if tagValue != "punctuation" && tagValue != "whitespace" {
                    let token = inputString[tokenRange]
                    keywords.append(String(token))
                }
            }
            return true
        }
        
        let stopWords: [String] = ["i", "me", "my", "myself", "we", "our", "ours", 
                                   "ourselves", "you", "your", "yours", "yourself", "yourselves", "he", "him", 
                                   "his", "himself", "she", "her", "hers", "herself", "it", "its", "itself", 
                                   "they", "them", "their", "theirs", "themselves", "what", "which", "who", 
                                   "whom", "this", "that", "these", "those", "am", "is", "are", "was", "were", 
                                   "be", "been", "being", "have", "has", "had", "having", "do", "does", "did", 
                                   "doing", "a", "an", "the", "and", "but", "if", "or", "because", "as", "until",
                                   "while", "of", "at", "by", "for", "with", "about", "against", "between", 
                                   "into", "through", "during", "before", "after", "above", "below", "to", 
                                   "from", "up", "down", "in", "out", "on", "off", "over", "under", "again", 
                                   "further", "then", "once", "here", "there", "when", "where", "why", "how", 
                                   "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", 
                                   "no", "nor", "not", "only", "own", "same", "so", "than", "too", "very", "s", 
                                   "t", "can", "will", "just", "don", "should", "now"]
        var wordCounts: [String: Int] = [:]
        for keyword in keywords {
            if !stopWords.contains(keyword) {
                if let count = wordCounts[keyword] {
                    wordCounts[keyword] = count + 1
                } else {
                    wordCounts[keyword] = 1
                }
            }
        }
        
        let sortedKeywords = wordCounts.sorted { $0.1 > $1.1 }
        let topKeywords = sortedKeywords.prefix(5).map { $0.key }
        
        let sentenceTokenizer = NLTokenizer(unit: .sentence)
        sentenceTokenizer.string = inputString
        let sentences = sentenceTokenizer.tokens(for: range).map { inputString[$0] }
        
        var sentenceScores: [String: Double] = [:]
        for sentence in sentences {
            let sentenceWords = sentence.lowercased().components(separatedBy: " ")
            var sentenceScore: Double = 0
            for keyword in topKeywords {
                if sentenceWords.contains(keyword.lowercased()) {
                    sentenceScore += Double(wordCounts[keyword]!)
                }
            }
            sentenceScores[String(sentence)] = sentenceScore
        }
        
        let sortedSentences = sentenceScores.sorted { $0.1 > $1.1 }
        let topSentences = sortedSentences.prefix(3).map { $0.key }
        
        summaryText = topSentences.joined(separator: "\n")
    }
}

struct ChatBot_Previews: PreviewProvider {
    static var previews: some View {
        TextSummarizer()
    }
}
