import SwiftUI

struct AIView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea(.all)
            ScrollView {
                VStack {
                    
                    // Artificial Intelligence (AI)
                    Message(centerText: "What is AI?", paraText: """
AI, short for Artificial Intelligence, refers to the ability of machines to perform tasks that normally require human intelligence. This includes activities such as learning, problem solving, understanding, and decision-making. It consists of many branches, including Machine Learning (ML), Natural Language Processing (NLP), Robotics, etc.
""", color: Color.pink.opacity(0.4))//, height: 400)
                    
                    // Machine Learning (ML)
                    Message(centerText: "What is Machine Learning (ML)?", paraText: """
Machine learning is a subfield of Artificial Intelligence that involves building computer algorithms and models that learn from data and improve their performance on specific tasks over time. It involves training a model on a dataset (called a training set) and then using that model to make decisions or make decisions on new data. 

There are three main types of machine learning: Supervised Learning, Unsupervised Learning, and Reinforcement Learning. In Supervised Learning, the model is trained in the data domain where each data point is associated with a particular outcome or goal. The goal is to examine a map of the input data and outputs. In Unsupervised Learning, a model is trained on unlabeled data to learn basic patterns or patterns in the data. In Reinforcement Learning, the model learns by trial and error by receiving instructions in the form of rewards or punishments depending on its behavior.
""", color: Color.purple.opacity(0.4))//, height: 700)
                    
                    // Natural Language Processing (NLP)
                    Message(centerText: "What is Natural Language Processing (NLP)?", paraText: """
Natural language processing, a subfield of Artificial Intelligence, it focuses on the interaction between the computers and the human language. The purpose of NLP is to enable computers to understand, interpret and reproduce both written and spoken human language. 

NLP includes many tasks such as Text Classification, Name Recognition, Sentiment Analysis, Translation, Text Generation and Text Classification. These tasks are accomplished using Machine Learning algorithms such as Deep Learning neural networks that are trained from large amounts of language data. 

NLP has many applications such as chatbots, virtual assistants, search engines, and language translation. It is also used to analyze social media data, customer feedback, and customer interactions. NLP has the potential to improve communication and effectiveness in many sectors, from healthcare to finance and education.
""", color: Color.indigo.opacity(0.4))//, height: 750)
                    
                    // Robotics
                    Message(centerText: "What is Robotics?\n", paraText: """
Robotics is the study of the design, development, and operation of robots. A robot is a machine that can perform complex tasks with minimal human intervention. Robots can be designed to perform a variety of tasks, from simple assembly tasks to multitasking tasks such as surgery, research, and office work.
""", color: Color.mint.opacity(0.4))//, height: 350)
                }
                .navigationTitle("What is AI?")
            }
        }
    }
}

struct MyView_Previews: PreviewProvider {
    static var previews: some View {
        AIView()
    }
}
