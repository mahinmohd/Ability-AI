import SwiftUI

struct MessageToApple: View {
    var body: some View {
        ZStack {
            Color.black.opacity(0.2).ignoresSafeArea(.all)
            ScrollView {
                VStack {
                    specialMessage(centerText: "Thank you, Apple!\n", paraText: """
I just wanted to take a moment to express my gratitude to SwiftUI. As a student learning mobile app development, I've found SwiftUI to be an essential tool for building beautiful and functional user interfaces across iOS, macOS, watchOS, and tvOS platforms. What I love most about SwiftUI is that it simplifies the entire UI design process. The report's content and easy-to-use design tools make it incredibly easy to create coherent and visually engaging content, keeping me focused on work and experience. The result is a simpler development process and better-performing fun apps. The Live Preview makes it easy to see the changes I've made to the UI in real time.

As a student, I'm still learning the intricacies of app development, but using SwiftUI I think I can create beautiful, great-looking apps without messing around with UI design. It has made my mobile app development journey more enjoyable and fulfilling.

Thanks again to the whole team at Apple for creating such a great tool.
""", color: .black, borderColor: .white)
                }
                .navigationTitle("A Meesage to Apple")
                .padding(.all)
            }
        }
    }
}

struct specialMessage: View {
    
    let centerText: String
    let paraText: String
    let color: Color
    let borderColor: Color
    
    @State private var messageHeight: CGFloat = 0
    
    var body: some View {
        VStack {
            Text(centerText)
                .multilineTextAlignment(.center)
                .font(.title.smallCaps().bold())
                .padding(.all, 15)
            
            Text(paraText)
                .font(.title2.lowercaseSmallCaps())
                .padding(.all, 20)
                .fixedSize(horizontal: false, vertical: true)
                .background(
                    GeometryReader { geometry in
                        Color.clear
                            .onAppear {
                                let height = geometry.size.height
                                if height > messageHeight {
                                    messageHeight = height
                                }
                            }
                    }
                )
        }
        .padding()
        .frame(width: 950, height: messageHeight + 90, alignment: .center)
        .background(color)
        .cornerRadius(15)
        .shadow(color: color, radius: 10, x: 0, y: 10)
        .overlay {
            RoundedRectangle(cornerRadius: 15)
                .stroke(borderColor, lineWidth: 2)
        }
    }
}

struct MessageToApple_Previews: PreviewProvider {
    static var previews: some View {
        MessageToApple()
    }
}
