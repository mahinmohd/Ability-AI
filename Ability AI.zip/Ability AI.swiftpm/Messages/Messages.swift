import SwiftUI

struct Message: View {
    
    let centerText: String
    let paraText: String
    let color: Color
    
    @State private var messageHeight: CGFloat = 0
    
    var body: some View {
        VStack {
            Text(centerText)
                .multilineTextAlignment(.center)
                .font(.title.smallCaps().bold())
                .padding(.all, 15)
            
            Text(paraText)
                .font(.title2.monospaced())
                .padding(.bottom, 15)
                .padding(.horizontal)
                .fixedSize(horizontal: false, vertical: true)
                .background(
                    GeometryReader { geometry in
                        Color.clear
                            .onAppear {
                                let height = geometry.size.height
                                if height > messageHeight {
                                    messageHeight = height
                                }
                            }
                    }
                )
        }
        .padding()
        .frame(width: 950, height: messageHeight + 90, alignment: .center)
        .background(color)
        .cornerRadius(15)
        .shadow(color: color, radius: 10, x: 0, y: 10)
    }
}
