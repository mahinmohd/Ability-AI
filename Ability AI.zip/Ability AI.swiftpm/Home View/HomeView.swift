import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color.black.ignoresSafeArea()
                Color.indigo.opacity(0.2).ignoresSafeArea(edges: .all)
                VStack(spacing: 30) {
                    Spacer()
                    HStack {
                        
                        // AI
                        VStack(spacing: 0) {
                            ZStack {
                                Rectangle()
                                    .fill(Color.purple.opacity(0.3))
                                    .frame(width: 350, height: 300, alignment: .center)
                                    .cornerRadius(30)
                                    .shadow(color: .black, radius: 10, x: 0, y: 10)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 25)
                                            .stroke(Color.indigo, lineWidth: 5)
                                    )
                                    .padding(.horizontal, 50)
                                
                                VStack(spacing: 30) {
                                    Text("AI")
                                        .font(.title.bold())
                                        .underline(color: Color.white)
                                        .shadow(color: .black.opacity(0.4), radius: 5, x: 0, y: 10)
                                    // Button for AIView
                                    Buttons(color: .purple.opacity(0.7), text: "What's AI?", Destination: AnyView(AIView()))
                                        .shadow(color: .black, radius: 30, x: 0, y: 0)
                                        .padding(.horizontal)
                                    
                                    // Button for Tic-Tac-Toe
                                    Buttons(color: .indigo.opacity(0.7), text: "Tic-Tac-Toe", Destination: AnyView(TicTacToeMainView()))
                                        .shadow(color: .black, radius: 30, x: 0, y: 0)
                                        .padding(.horizontal)
                                }
                            }
                            .padding(.all)
                            
                            // Message to Apple 
                            specialButton(color: .black.opacity(0.7), text: "A Message To ", Destination: AnyView(MessageToApple()))
                                .shadow(color: .black, radius: 30, x: 0, y: 0)
                                .padding(.horizontal)
                                .overlay {
                                    RoundedRectangle(cornerRadius: 80)
                                        .stroke(Color.white, lineWidth: 5)
                                        .frame(width: 300, height: 70, alignment: .center)
                                }
                                .padding(.top, 25)
                                .padding(.bottom)
                        
                        }
                        
                        // NLP
                        ZStack {
                            Rectangle()
                                .fill(Color.cyan.opacity(0.3))
                                .frame(width: 350, height: 400, alignment: .center)
                                .cornerRadius(30)
                                .shadow(color: .black, radius: 10, x: 0, y: 10)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 25)
                                        .stroke(Color.cyan, lineWidth: 5)
                                )
                                .padding(.horizontal, 50)
                            
                            VStack(spacing: 30) {
                                Text("NLP")
                                    .font(.title.bold())
                                    .underline(color: Color.white)
                                    .shadow(color: .black.opacity(0.4), radius: 5, x: 0, y: 10)
                                
                                // Button for ChatBot
                                Buttons(color: .mint.opacity(0.7), text: "NLP Steps", Destination: AnyView(NLPModel()))
                                    .shadow(color: .black, radius: 30, x: 0, y: 0)
                                    .padding(.horizontal)
                                
                                // Button for Stemming View
                                Buttons(color: .cyan.opacity(0.7), text: "Text Summarizer", Destination: AnyView(TextSummarizer()))
                                    .shadow(color: .black, radius: 30, x: 0, y: 0)
                                    .padding(.horizontal)
                                
                                // Button for Sentiment Analysis
                                Buttons(color: .blue.opacity(0.7), text: "Sentiment Analysis", Destination: AnyView(Sentiments()))
                                    .shadow(color: .black, radius: 30, x: 0, y: 0)
                                    .padding(.horizontal)
                            }
                        }
                        .padding(.all)
                    
                    }
                    
                    
                    
                }
                .padding(.all, 15)
                .navigationTitle("Ability AI")
                .padding(.bottom, 50)
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            UIDevice.current.setValue(UIInterfaceOrientation.landscapeRight.rawValue, forKey: "orientation")
        }
    }
    var prefersStatusBarHidden: Bool {
        return true
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
