import SwiftUI

@main
struct AbilityAI: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
