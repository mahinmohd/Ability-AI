import SwiftUI

struct OXButtons: View {
    
    @Binding var letter: String
    @State private var RotDegree: Double = 0
    
    var body: some View {
        ZStack {
            Rectangle()
                .frame(width: 100, height: 100)
                .foregroundColor(.indigo)
                .cornerRadius(30)
                .shadow(color: .indigo.opacity(0.8), radius: 20, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: 10)
            Text(letter)
                .font(.system(size: 60))
                .foregroundColor(.black)
                .bold()
        }
        .padding()
        .rotation3DEffect(
            .degrees(RotDegree), axis: (x: 0.0, y: 1.0, z: 0.0)
        )
        .gesture(
        TapGesture()
            .onEnded { _ in
                withAnimation(.interpolatingSpring(mass: 1, stiffness: 5, damping: 10, initialVelocity: 5)) {
                    self.RotDegree -= 180
                }
            }
        )
    }
}

struct OXButtons_Previews: PreviewProvider {
    static var previews: some View {
        OXButtons(letter: .constant("X"))
    }
}
