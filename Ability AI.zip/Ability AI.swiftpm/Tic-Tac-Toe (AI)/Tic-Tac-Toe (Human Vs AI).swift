import SwiftUI

struct TicTacToeMainView: View {
    
    @State private var moves = ["", "", "", "", "", "", "", "", ""]
    @State private var EndGame = false
    @State private var Winner = ""
    private var ranges = [(0..<3), (3..<6), (6..<9)]
    @State private var buttonTapped = false
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack {          
                Spacer()
                Text("Tic-Tac-Toe")
                    .font(.title)
                    .foregroundColor(.blue)
                    .shadow(color: .blue, radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/)
                    .bold()
                Text("Human VS Bot")
                    .font(.system(size: 35))
                    .foregroundColor(.cyan)
                    .shadow(color: .blue, radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/)
                    .bold()
                Spacer()
                ForEach(ranges, id: \.self) { range in
                    HStack {
                        ForEach(range, id: \.self) { ox in
                            OXButtons(letter: $moves[ox])
                                .simultaneousGesture(
                                    TapGesture()
                                        .onEnded { _ in
                                            OXTap(index: ox)
                                        }
                                )
                        }
                    }
                }
                
                Spacer()
                
                Button(action: {
                    withAnimation() {
                        self.buttonTapped.toggle()
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                        withAnimation {
                            self.buttonTapped.toggle()
                        }
                    }
                    ClearBoard()  
                }) {
                    Text("Clear")
                        .frame(width: 100, height: 50, alignment: .center)
                        .foregroundColor(.black)
                        .font(.title3.smallCaps())
                        .background(Color.cyan)
                        .cornerRadius(30)
                        .shadow(color: .cyan, radius: 40, x: /*@START_MENU_TOKEN@*/0.0/*@END_MENU_TOKEN@*/, y: 15)
                        .scaleEffect(buttonTapped ? 0.9 : 1)
                }
                
                    
                Spacer()
            }
            .padding(.bottom, 100)
            .alert(isPresented: $EndGame) {
                Alert(title: Text(Winner), message: Text("Do you want to play again?"), primaryButton: .default(Text("Yes"), action: ClearBoard), secondaryButton: .cancel())
            }
        }
    }
    
    // Placing the X for the User
    func OXTap(index: Int) {
        if moves[index] == "" {
            withAnimation(.easeIn(duration: 0.6)) {
                moves[index] = "X"
                if !checkWinner(list: moves, letter: "X") {
                    AIMove()
                }
            }
        }
        
        let isBoardFull = moves.filter { $0 == "" }.count == 0
        if !checkWinner(list: moves, letter: "X") && !checkWinner(list: moves, letter: "O") && isBoardFull {
            Winner = "Draw"
            EndGame = true
        } else {
            for letter in ["X", "O"] {
                if checkWinner(list: moves, letter: letter) {
                    if letter == "X" {
                        Winner = "X Won!"
                    } else if letter == "O" {
                        Winner = "O Won!"
                    }
                    EndGame = true
                    break
                }
            }
        }
    }
    
    // AI Moves
    func AIMove() {
        var freeSpace: [Int] = []
        var movesLeft = 0
        
        // Finding all the empty spaces in the board
        for move in moves {
            if move == "" {
                freeSpace.append(movesLeft)
            }
            movesLeft += 1
        }
        
        // If the bot can win, it will place O and win
        for index in freeSpace {
            var tempMoves = moves
            tempMoves[index] = "O"
            if checkWinner(list: tempMoves, letter: "O") {
                moves[index] = "O"
                return
            }
        }
        
        // If the user can win in the next move, block it.
        for index in freeSpace {
            var tempMoves = moves
            tempMoves[index] = "X"
            if checkWinner(list: tempMoves, letter: "X") {
                moves[index] = "O"
                return
            }
        }
        
        // Place the O randomly in the available free spaces.
        if freeSpace.count != 0 {
            moves[freeSpace.randomElement()!] = "O"
        }
    }

    
    // Checking Winner
    func checkWinner(list: [String], letter: String) -> Bool {
        let winningSequences = [[0, 1, 2], [3, 4, 5], [6, 7, 8], 
                                [0, 4, 8], [2, 4, 6], 
                                [0, 3, 6], [1, 4, 7], [2, 5, 8]]
        for sequence in winningSequences {
            var score = 0
            for match in sequence {
                if list[match] == letter {
                    score += 1
                    if score == 3 {
                        return true
                    }
                }
            }
        }
        return false
    }
    // Clear the Board Button
    func ClearBoard() {
        withAnimation(.easeOut(duration: 0.4)) {
            moves = ["", "", "", "", "", "", "", "", ""]
        }
    }
}

struct TicTacToe_Previews: PreviewProvider {
    static var previews: some View {
        TicTacToeMainView()
    }
}
