import SwiftUI
import NaturalLanguage

struct Sentiments: View {
    
    // All the required State Variables
    @State private var input = ""
    @State private var score: Double = 0.0
    @State private var bgColor: Color = Color.black
    
    var body: some View {
        ZStack {
            
            // Background Colors Changing Based on Sentiment
            self.ColorChange(color: bgColor).opacity(0.3).ignoresSafeArea(edges: .all)
            ScrollView {
                VStack(spacing: 15) {
                    Text("Sentiment Analyser")
                        .padding(.top, 30)
                        .font(.largeTitle.lowercaseSmallCaps().bold())
                        .underline(true, color: bgColor)
                    
                    Spacer()
                    VStack {
                        Text("Example Text")
                            .font(.title3.lowercaseSmallCaps().bold())
                            .padding(.top, 50)
                        HStack {
                            Spacer()
                            
                            // Buttons for Sample Text
                            Button(action: {
                                input = "I lost my job today and I don't know how I'm going to pay my bills. I feel like I've let down my family and I don't know what to do next. I'm so worried about the future and how I'm going to make ends meet."
                            }) {
                                Text("Sad")
                                    .foregroundColor(.white)
                                    .font(.title3.smallCaps())
                                    .padding()
                                    .background(Color.red.opacity(0.6))
                                    .cornerRadius(25)
                                    .shadow(color: .red.opacity(0.3), radius: 10, x: 0, y: 10)
                                    .padding(.top, 50)
                            }
                            Spacer()
                            Button(action: {
                                input = "Wow, Great"
                            }) {
                                Text("Neutral")
                                    .foregroundColor(.white)
                                    .font(.title3.smallCaps())
                                    .padding()
                                    .background(Color.black.opacity(0.6))
                                    .cornerRadius(25)
                                    .shadow(color: .black.opacity(0.3), radius: 10, x: 0, y: 10)
                                    .padding(.top, 50)
                            }
                            Spacer()
                            Button(action: {
                                input = "I just got a promotion at work and I'm so excited! I've been working towards this for months and it finally happened. I can't wait to celebrate with my friends and family tonight."
                            }) {
                                Text("Happy")
                                    .foregroundColor(.white)
                                    .font(.title3.smallCaps())
                                    .padding()
                                    .background(Color.green.opacity(0.6))
                                    .cornerRadius(25)
                                    .shadow(color: .green.opacity(0.3), radius: 10, x: 0, y: 10)
                                    .padding(.top, 50)
                            }
                            Spacer()
                        }
                        .frame(width: .infinity)
                        .padding(.horizontal)
                    }
                    HStack {
                        TextField("Enter text here", text: $input)
                            .padding()
                            .background(Color.purple.opacity(0.3))
                            .cornerRadius(15)
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.purple, lineWidth: 2)
                            )
                            .onSubmit {
                                withAnimation(.easeIn(duration: 0.4)) {
                                    self.analyzeSentiment()
                                }
                            }
                        
                        // Button to Clear off the input Text
                        Button(action: {
                            withAnimation(.easeOut(duration: 0.4)) {
                                self.input = ""
                                self.bgColor = Color.black
                                self.score = 0
                            }  
                        }) {
                            Text("Clear")
                                .padding()
                                .frame(height: 50, alignment: .center)
                                .font(.title3.smallCaps())
                                .foregroundColor(.white)
                                .background(Color.pink.opacity(0.5))
                                .cornerRadius(15)
                        }
                    }
                    
                    Button(action: {
                        withAnimation(.easeIn(duration: 0.4)) {
                            self.analyzeSentiment()
                        }  
                    }) {
                        Text("Analyse")
                            .padding()
                            .frame(height: 50, alignment: .center)
                            .font(.title3.smallCaps())
                            .foregroundColor(.white)
                            .background(Color.purple.opacity(0.8))
                            .cornerRadius(15)
                    }
                    
                    // Showing up the Emoji based on Sentiment
                    Text(sentimentEmoji())
                        .font(.system(size: 50))
                        .padding(.top, 60)
                    Text(sentimentText())
                        .font(.system(size: 20).smallCaps())
                    
                    Spacer()
                    // Sentiment Score
                    Text("Sentiment score\n \(Int(score * 100))")
                        .padding()
                        .font(.title3.smallCaps())
                        .multilineTextAlignment(.center)
                        .background(bgColor)
                        .cornerRadius(15)
                    
                    
                    Spacer()
                }
                .navigationTitle("Sentiment Analysis")
                .navigationBarTitleDisplayMode(.inline)
                .padding(.horizontal, 20)
            }
        }
    }
    
    // Using NLP to analyze sentiments
    func analyzeSentiment() {
        let tagger = NLTagger(tagSchemes: [.sentimentScore])
        tagger.string = input
        let sentiment = tagger.tag(at: input.startIndex, unit: .paragraph, scheme: .sentimentScore).0
        score = Double(sentiment?.rawValue ?? "0") ?? 0
        bgColor = self.colorFromScore(score: score)
    }
    
    // Emoji on the screen based in Sentiment
    func sentimentEmoji() -> String {
        switch score {
        case 0:
            return "🙂"
        case ..<0:
            return "😢"
        default:
            return "😁"
        }
    }
    
    func sentimentText() -> String {
        switch score {
        case 0:
            return "Neutral"
        case ..<0:
            return "Sad"
        default:
            return "Happy"
        }
    }
    
    // Background Colors Changing based on Emoji
    func colorFromScore(score: Double) -> Color {
        switch score {
        case 0:
            return Color.black
        case ..<0:
            return Color.red
        default:
            return Color.green
        }
    }
    
    // Showing the Colors in the View
    func ColorChange(color: Color) -> some View {
        Rectangle()
            .foregroundColor(color)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Sentiments()
    }
}
